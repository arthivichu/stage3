package org.example.exception;

public class InvalidTraineeDataException extends RuntimeException{

	public InvalidTraineeDataException(String message) {
		super(message);
	}

}
