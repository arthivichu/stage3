package com.cognizant.ormlearn.StockRepository;

import org.springframework.stereotype.Repository;

import com.cognizant.ormlearn.model.Stock.Stock;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

@Repository
public interface StockRepository extends JpaRepository<Stock,Integer> {

	@Query(value = "SELECT u FROM Stock u  WHERE u.date BETWEEN ?1 AND ?2")
	public List<Stock> getStockBasedOnDate(Date startDate, Date endDate);
	
	@Query(value="SELECT u FROM Stock u WHERE u.open > ?1 AND u.close=?1")
	public List<Stock> getStockBasedOnPrice(long price);
	
	@Query(value="SELECT * FROM Stock u ORDER BY u.st_volume DESC LIMIT ?1",nativeQuery=true)
	public List<Stock> getTopThreeTransactions(long limit);
	
	@Query(value="SELECT * FROM Stock u ORDER BY u.st_volume LIMIT ?1",nativeQuery=true)
	public List<Stock> getLowestNfStock(long limit);
	
	
}
