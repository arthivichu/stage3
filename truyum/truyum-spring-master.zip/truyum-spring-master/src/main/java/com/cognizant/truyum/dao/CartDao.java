package com.cognizant.truyum.dao;

import java.util.List;
import java.util.Set;

import com.cognizant.truyum.exception.CartEmptyException;
import com.cognizant.truyum.model.MenuItem;

public interface CartDao {
	void addCartItem(long userId, long menuItemId);

	Set<MenuItem> getAllCartItems(long userId) throws CartEmptyException;

	void removeCartItem(long userId, long menuItemId);
}
