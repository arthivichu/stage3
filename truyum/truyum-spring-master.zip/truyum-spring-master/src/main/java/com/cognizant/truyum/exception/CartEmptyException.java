package com.cognizant.truyum.exception;

public class CartEmptyException extends Exception {
	public CartEmptyException(String message) {
		super(message);
	}
}
